## 环境安装

``` bash
pip install -r requirements.txt
pip install torch==1.12.1+cu116 torchvision==0.13.1+cu116 torchaudio==0.12.1 --extra-index-url https://download.pytorch.org/whl/cu116
```

if render:

``` bash
apt-get install python-opengl
```

if mpe:

``` bash
pip install gym==0.25.1
```

## 工具

Xvfb :10 -screen 0 1024x768x16 &
export DISPLAY=:10
pkill -9 Xvfb

## 实验脚本

见/scripts文件夹下。

## 实验结果

### 原始结果

见/results文件夹下，具体子文件夹名参考对应的训练脚本。

### 论文图片

见/figures文件夹，是由/results文件夹下的脚本生成的。