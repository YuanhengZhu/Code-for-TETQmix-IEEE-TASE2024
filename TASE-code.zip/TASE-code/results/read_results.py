import json
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from datetime import datetime

titles = ["Spread", "Form Shape", "Push", "Tag 1", "Tag 2", "Mean"]


methods = [
    "transfqmixtask",
    "transfqmix_multihead",
    "transfqmixme",
    "mixofencoders",
    "V1+imp",
    "V1",
]
methods_other_name = {
    "transfqmixtask": "TransfQmix-task",
    "transfqmix_multihead": "TransfQmix-multihead",
    "transfqmixme": "TransfQmix-me",
    "mixofencoders": "MLPQmx-me",
    "V1+imp": "TETQmix (ours)",
    "V1": "TETQmix (w/o reg)",
}
method_dirs = {
    "transfqmixtask": "results/ExpRewardNormSeriesTaskRecord/ExpRewardNormTransfqmixTask/sacred/mpe/multi_with_task/transf_qmix",
    "transfqmix_multihead": "results/ExpRewardNormSeriesTaskRecord/ExpRewardNormTransfqmixHead/sacred/mpe/multi/transf_qmix",
    "transfqmixme": "results/ExpRewardNormSeriesTaskRecord/ExpRewardNormTransfqmixMeTrue/sacred/mpe/multi/transf_qmix",
    "mixofencoders": "results/ExpRewardNormSeriesTaskRecord/ExpRewardNormTransfqmixMe/sacred/mpe/multi/transf_qmix",
    "V1+imp": "results/ExpRewardNormSeriesTaskRecord/ExpRewardNormOursImp/sacred/mpe/multi/transf_qmix_task_cross",
    "V1": "results/ExpRewardNormSeriesTaskRecord/ExpRewardNormOursV1/sacred/mpe/multi/transf_qmix_task_cross",
}


def read_result(method):
    method_dir = method_dirs[method]
    runtimes = []
    for id in os.listdir(method_dir):
        if id.isdigit():
            file_path = os.path.join(method_dir, id, "metrics.json")
            with open(file_path, "r") as f:
                metrics = json.load(f)
            runtime_start = metrics["episode"]["timestamps"][0]
            runtime_end = metrics["episode"]["timestamps"][-1]
            runtime_start = datetime.fromisoformat(runtime_start)
            runtime_end = datetime.fromisoformat(runtime_end)
            runtime = runtime_end - runtime_start
            # print(f"{method}: {runtime}")
            runtimes.append(runtime)
    mean_runtime = np.mean(runtimes)
    return mean_runtime

for method in methods:
    mean_runtime = read_result(method)
    print(f"{method}: {mean_runtime}")