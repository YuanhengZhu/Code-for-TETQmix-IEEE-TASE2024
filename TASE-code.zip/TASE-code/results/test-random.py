import random
import sys
sys.path.append('.')
sys.path.append('src')

import numpy as np

from src.envs import REGISTRY as env_REGISTRY



tasks = ["spread", "form_shape", "push", "tag1", "tag2"]

for task in tasks:
    env_args = {
        "key": task,
        "obs_entity_mode": True,
        "state_entity_mode": True,
        "time_limit": 25,
        "seed": 1,
    }

    env = env_REGISTRY["mpe"](**env_args)

    returns = []

    for i in range(500):
        env.reset()
        terminated = False

        ret = 0
        while not terminated:
            actions = [random.randint(0, 4) for _ in range(env.n_agents)]
            reward, terminated, env_info = env.step(actions)
            ret += reward
        
        returns.append(ret)

    print(env_args["key"], "\t", np.mean(returns))
