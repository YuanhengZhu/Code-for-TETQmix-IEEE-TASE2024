import json
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


# 平滑数据
def smooth(data, weight=0.6):
    if weight >= 1 or weight < 0:
        raise AttributeError("Weight should be greater than 0 and less than 1.")

    scalar = data["Value"].values
    last = scalar[0]
    smoothed = []
    for point in scalar:
        smoothed_val = last * weight + (1 - weight) * point
        smoothed.append(smoothed_val)
        last = smoothed_val

    result = pd.DataFrame({"Step": data["Step"].values, "Value": smoothed})
    return result


plt.figure() 

titles = ["Push Away"]

methods = [
    "multi-PLM_no_grad (ours)",
    "multi-PLM (new prompts)",
    "multi-TC",
    "multi-LE",
]
method_other_name = {
    "multi-PLM_no_grad (ours)": "multi-PLM(USE)",
    "multi-PLM (new prompts)": "multi-PLM(USE,new prompts)",
}
method_dirs = {
    "multi-PLM (ours)": "results/ExpNewTask/ExpNewTaskOursImpUse1/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-PLM_no_grad (ours)":"results/ExpNewTask/ExpNewTaskOursImpUse_no_grad/sacred/mpe/push_away/transf_qmix_task_cross",
    # "LLM(fixed)": "results/ExpNewTask/ExpNewTaskOursImpUse/sacred/mpe/push_away/transf_qmix_task_cross",
    # "LLM2": "results/ExpNewTask/ExpNewTaskOursImpUse2/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-TC": "results/ExpNewTask/ExpNewTaskOursV2Paco1/sacred/mpe/push_away/transf_qmix_task_cross",
    # "CompositionOfTasks(fixed)": "results/ExpNewTask/ExpNewTaskOursV2Paco/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-LE": "results/ExpNewTask/ExpNewTaskLearnEncodings/sacred/mpe/push_away/transf_qmix_task_cross",
    "Spread": "results/ExpNewTask/ExpSpreadAndNew/sacred/mpe/push_away/transf_qmix",
    "single-Form Shape": "results/ExpNewTask/ExpFormShapeAndNew/sacred/mpe/push_away/transf_qmix",
    "single-Push": "results/ExpNewTask/ExpPushAndNew/sacred/mpe/push_away/transf_qmix",
    "single-Tag 1": "results/ExpNewTask/ExpTag1AndNew/sacred/mpe/push_away/transf_qmix",
    "Tag 2": "results/ExpNewTask/ExpTag2AndNew/sacred/mpe/push_away/transf_qmix",
    "from scratch": "results/ExpNewTask/ExpNewTaskTransfqmixSingle/sacred/mpe/push_away/transf_qmix",
    "multi-PLM (new prompts)": "results/ExpNewTask/ExpNewTaskOursImpUse_new_prompt/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-PLM (random)":"results/ExpNewTask/ExpNewTaskOursImpUse_random_new_task/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-PLM (T5)":"results/ExpNewTask/ExpNewTaskOursImpUse_T5_new_task/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-PLM (T5_normalize)":"results/ExpNewTask/ExpNewTaskOursImpUse_T5_new_task_normalize/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-PLM (SentenceTransformer)": "results/ExpNewTask/ExpNewTaskOursImpUse_Sentence_transformers_new_task/sacred/mpe/push_away/transf_qmix_task_cross",
}

# 遍历需要绘制的数据

# 读取数据
data_frames = pd.DataFrame(columns=["Step", "Value", "Method"]).reset_index(
    drop=True
)
for method in methods:
    method_dir = method_dirs[method]
    for id in os.listdir(method_dir):
        if id.isdigit():
            file_path = os.path.join(method_dir, id, "metrics.json")
            with open(file_path, "r") as f:
                metrics = json.load(f)
            key = "test_return_mean_{}".format(5)
            x = np.array(metrics[key]["steps"])
            y = np.array(metrics[key]["values"])
            data = pd.DataFrame({"Step": x, "Value": y})
            data = smooth(data, weight=0.6)
            x = data["Step"].values / 1e5
            y = data["Value"].values
            data_frames = pd.concat(
                (
                    data_frames,
                    pd.DataFrame(
                        {
                            "Train Step": x,
                            "Test Return": y,
                            "Method": method_other_name[method]
                            if method in method_other_name
                            else method,
                        }
                    ),
                ),
                ignore_index=True,
            )

# 计算子图的行和列
row = 0
col = 0

# 绘制子图
sns.lineplot(
    x="Train Step",
    y="Test Return",
    hue="Method",
    ax=plt.gca(),
    ci=60,
    data=data_frames,
)

# plt.title("Unseen Task: Push Away")
plt.xlabel("Train Step", fontsize=12)
plt.ylabel("Test Return", fontsize=12)
# 设置x轴的范围
# plt.xlim(0, 200000)

# 保存图形
# plt.show()
plt.savefig("figures/newtask-prompt.svg", dpi=300)
plt.savefig("figures/newtask-prompt.png", dpi=300)
