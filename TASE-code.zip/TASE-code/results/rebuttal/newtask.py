import json
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


# 平滑数据
def smooth(data, weight=0.6):
    if weight >= 1 or weight < 0:
        raise AttributeError("Weight should be greater than 0 and less than 1.")

    scalar = data["Value"].values
    last = scalar[0]
    smoothed = []
    for point in scalar:
        smoothed_val = last * weight + (1 - weight) * point
        smoothed.append(smoothed_val)
        last = smoothed_val

    result = pd.DataFrame({"Step": data["Step"].values, "Value": smoothed})
    return result


plt.figure() 

titles = ["Push Away"]

methods = [
    "multi-PLM",
    "multi-PLM-with-numbers",
    "multi-TC",
    "multi-LE",
]
method_dirs = {
    "multi-PLM": "results/rebuttal/ExpNewTaskMultiPLMwithourNumber/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-PLM-with-numbers": "results/rebuttal/ExpNewTaskMultiPLM/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-TC": "results/rebuttal/ExpNewTaskMultiTC/sacred/mpe/push_away/transf_qmix_task_cross",
    "multi-LE": "results/rebuttal/ExpNewTaskMultiLE/sacred/mpe/push_away/transf_qmix_task_cross",
}

# 遍历需要绘制的数据

# 读取数据
data_frames = pd.DataFrame(columns=["Step", "Value", "Method"]).reset_index(
    drop=True
)
for method in methods:
    method_dir = method_dirs[method]
    for id in os.listdir(method_dir):
        if id.isdigit():
            file_path = os.path.join(method_dir, id, "metrics.json")
            with open(file_path, "r") as f:
                metrics = json.load(f)
            key = "test_return_mean_{}".format(5)
            x = np.array(metrics[key]["steps"])
            y = np.array(metrics[key]["values"])
            data = pd.DataFrame({"Step": x, "Value": y})
            data = smooth(data, weight=0.8)
            x = data["Step"].values / 1e5
            y = data["Value"].values
            data_frames = pd.concat(
                (
                    data_frames,
                    pd.DataFrame(
                        {
                            "Train Step": x,
                            "Test Return": y,
                            "Method": method,
                        }
                    ),
                ),
                ignore_index=True,
            )

# 计算子图的行和列
row = 0
col = 0

# 绘制子图
sns.lineplot(
    x="Train Step",
    y="Test Return",
    hue="Method",
    ax=plt.gca(),
    ci=60,
    data=data_frames,
)

# plt.title("Unseen Task: Push Away")
plt.xlabel("Train Step", fontsize=12)
plt.ylabel("Test Return", fontsize=12)
# 设置x轴的范围
# plt.xlim(0, 200000)

# 保存图形
plt.savefig("figures/rebuttal_newtask.svg", dpi=300)
plt.savefig("figures/rebuttal_newtask.png", dpi=300)
