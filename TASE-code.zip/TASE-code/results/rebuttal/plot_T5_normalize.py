import json
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


# 平滑数据
def smooth(data, weight=0.6):
    if weight >= 1 or weight < 0:
        raise AttributeError("Weight should be greater than 0 and less than 1.")

    scalar = data["Value"].values
    last = scalar[0]
    smoothed = []
    for point in scalar:
        smoothed_val = last * weight + (1 - weight) * point
        smoothed.append(smoothed_val)
        last = smoothed_val

    result = pd.DataFrame({"Step": data["Step"].values, "Value": smoothed})
    return result


# 定义子图布局
fig, axs = plt.subplots(2, 3, figsize=(12, 6))

titles = ["Spread", "Form Shape", "Push", "Tag 1", "Tag 2", "Mean"]
HB = [1.811926606, 2.399345336, 1.634920635, 2.876140808, 1.001747353, 1.944816148]

methods = [
    "USE",
    "T5",
    "T5_normalize"
]
colors = {
    "USE": "#1f77b4",
    "T5": "#ff7f0e",
    "T5_normalize": "#2ca02c",
}
custom_palette = list(colors.values())
another_custom_palette = [custom_palette[-1]]
custom_palette = custom_palette[:-1]

methods_other_name = {
    "transfqmixtask": "TransfQmix-task",
    "transfqmix_multihead": "TransfQmix-multihead",
    "transfqmixme": "TransfQmix-me",
    "mixofencoders": "MLPQmx-me",
    "V1+imp": "TETQmix (ours)",
    "V1": "TETQmix (w/o reg)",
}
method_dirs = {
    "USE": "results/Rebuttal/buffer_size/5000/sacred/mpe/multi/transf_qmix_task_cross",
    "T5": "results/Rebuttal/T5/sacred/mpe/multi/transf_qmix_task_cross",
    "T5_normalize":"results/Rebuttal/T5_normalize/sacred/mpe/multi/transf_qmix_task_cross"
}


def read_result(method, i, data_frames):
    method_dir = method_dirs[method]
    for id in os.listdir(method_dir):
        if id.isdigit():
            file_path = os.path.join(method_dir, id, "metrics.json")
            with open(file_path, "r") as f:
                metrics = json.load(f)
            if i != 5:
                key = "test_return_mean_{}".format(i)
                x = np.array(metrics[key]["steps"])
                y = np.array(metrics[key]["values"])
                if i == 4:
                    y = y * 1.010998047
            else:
                # mean
                x = np.array(metrics["test_return_mean_0"]["steps"])
                y = np.array(
                    [
                        np.mean(
                            [
                                metrics["test_return_mean_0"]["values"][j],
                                metrics["test_return_mean_1"]["values"][j],
                                metrics["test_return_mean_2"]["values"][j],
                                metrics["test_return_mean_3"]["values"][j],
                                metrics["test_return_mean_4"]["values"][j] * 1.010998047,
                            ]
                        )
                        for j in range(len(metrics["test_return_mean_0"]["values"]))
                    ]
                )
            data = pd.DataFrame({"Step": x, "Value": y})
            data = smooth(data, weight=0.6)
            x = data["Step"].values
            y = data["Value"].values
            data_frames = pd.concat(
                (
                    data_frames,
                    pd.DataFrame(
                        {
                            "Train Step": x,
                            "Test Return": y,
                            "Method": methods_other_name[method]
                            if method in methods_other_name
                            else method,
                        }
                    ),
                ),
                ignore_index=True,
            )
    return data_frames


# 遍历需要绘制的数据
for i in range(6):
    # 读取数据
    data_frames = pd.DataFrame(columns=["Step", "Value", "Method"]).reset_index(
        drop=True
    )
    another_data_frames = pd.DataFrame(columns=["Step", "Value", "Method"]).reset_index(
        drop=True
    )
    for method in methods[:-1]:
        data_frames = read_result(method, i, data_frames)
    method = methods[-1]
    another_data_frames = read_result(method, i, another_data_frames)

    # 计算子图的行和列
    row = i // 3
    col = i % 3

    # 绘制子图
    sns.lineplot(
        x="Train Step",
        y="Test Return",
        hue="Method",
        palette=custom_palette,
        ax=axs[row][col],
        data=data_frames,
    )
    sns.lineplot(
        x="Train Step",
        y="Test Return",
        hue="Method",
        palette=another_custom_palette,
        linestyle="--",
        ax=axs[row][col],
        data=another_data_frames,
    )

    # 在y=1处画一条虚线
    axs[row, col].axhline(y=1, color="blue", linestyle="--")
    axs[row, col].axhline(y=HB[i], color="red", linestyle=":")
    if col == 0:
        axs[row, col].set_ylabel("Test Return")
    else:
        # 删除ylabel
        axs[row, col].set_ylabel("")
    if row == 1:
        axs[row, col].set_xlabel("Train Step")
    else:
        # 删除xlabel
        axs[row, col].set_xlabel("")
    if i != 0:
        # 删除标注框
        axs[row, col].legend().remove()

# 调整子图布局和间距
fig.tight_layout()
plt.subplots_adjust(hspace=0.3)

# 遍历所有子图，删除空白的子图
for ax in axs.flat:
    # 检查子图是否为空
    if not ax.lines:
        # 删除子图
        ax.remove()

# 保存图形
# plt.show()
plt.savefig("figures/plot-T5_normalize.png", dpi=300)
# plt.savefig("figures/plot-baseline.svg", dpi=300)
