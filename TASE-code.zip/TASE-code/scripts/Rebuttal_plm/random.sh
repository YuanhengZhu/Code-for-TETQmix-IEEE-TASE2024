#!/bin/bash
cd ..
cd ..
LOCAL_RESULTS_PATH="results/Rebuttal/random"

# 如果用户传入了一个数字参数，就使用该数字作为循环次数，否则默认循环3次
if [ -n "$1" ] && [ "$1" -eq "$1" ] 2>/dev/null; then
    LOOP_COUNT="$1"
else
    LOOP_COUNT=3
fi

for i in $(seq 1 "$LOOP_COUNT")
do
    export CUDA_VISIBLE_DEVICES=1
    COMMAND=" python src/main.py alg-config=transf_qmix_task_cross env-config=mpe/multi local_results_path=${LOCAL_RESULTS_PATH} run=run_imp agent=n_transf_agent_task_cross_use_v1_random buffer_size=5000 emb=32 heads=1 depth=3 ff_hidden_mult=1 mixer_emb=32 mixer_heads=1 buffer_cpu_only=False t_max=1000000"
    echo "Running command: ${COMMAND}"
    ${COMMAND}
done
# cd scripts
# conda activate mt514
# bash ExpRewardNormOursImp.sh