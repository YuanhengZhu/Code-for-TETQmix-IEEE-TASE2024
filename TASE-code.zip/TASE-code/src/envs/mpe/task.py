class Task:
    def __init__(self) -> None:
        self.num_agents = 5
        self.num_landmarks = 5
        self.type = 0 # 0: spread 1: form shape
        self.shape = 0
