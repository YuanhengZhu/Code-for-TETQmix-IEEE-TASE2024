from .run import run as default_run
from .run_save import run as run_save
from .run_multi import run as run_multi
from .run_imp import run as run_imp
from .run_new import run as run_new
from .run_mamujoco import run as run_mamujoco
from .run_imp_psample_003 import run as run_imp_psample_003
from .run_imp_psample_010 import run as run_imp_psample_010
from .run_imp_psample_030 import run as run_imp_psample_030
from .run_imp_psample_015 import run as run_imp_psample_015


REGISTRY = {}
REGISTRY["default"] = default_run
REGISTRY["run_save"] = run_save
REGISTRY["run_multi"] = run_multi
REGISTRY["run_imp"] = run_imp
REGISTRY["run_new"] = run_new
REGISTRY["run_mamujoco"] = run_mamujoco
REGISTRY["run_imp_psample_003"] = run_imp_psample_003
REGISTRY["run_imp_psample_010"] = run_imp_psample_010
REGISTRY["run_imp_psample_030"] = run_imp_psample_030
REGISTRY["run_imp_psample_015"] = run_imp_psample_015
